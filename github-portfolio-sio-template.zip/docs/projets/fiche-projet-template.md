# Fiche projet — {NOM DU PROJET}

- **Contexte** : entreprise / cours / stage / alternance
- **Périmètre** : fonctionnalités, besoins adressés
- **Environnement** : techno, versions, outillage
- **Compétences visées (E4/E5)** : lister les compétences du référentiel

## 1. Objectifs
- Objectif 1
- Objectif 2

## 2. Conception & mise en œuvre
- Architecture, schémas (mettre images dans `assets/`)
- Choix techniques argumentés
- Sécurité / qualité / performances

## 3. Résultats & livrables
- Captures d’écran, démonstration
- Livrables fournis (code, manuel utilisateur, scripts de déploiement)

## 4. Tests & validation
- Stratégie de tests (unitaires, intégration, recette)
- Résultats clés

## 5. Bilan & améliorations
- Points forts / limites
- Pistes d’amélioration, dette technique

## 6. Lien vers le code
- `src/` ou dépôt spécifique si séparé
