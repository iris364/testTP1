# Fiche de veille — {TITRE COURT}

- **Date** : AAAA‑MM‑JJ
- **Source** : Titre — Lien
- **Thème** : (ex. “Nouveautés PHP 8.2”, “Docker en production”, “Sécurité API REST”)

## Résumé (3–5 lignes max)
Écrire ici l’idée principale de l’article/vidéo. Aller à l’essentiel (pas de copier/coller).

## Impact métier (2–3 phrases)
Expliquer **en quoi** cette information change votre pratique en entreprise (SLAM/SISR).

## Mots‑clés
`#php` `#sécurité` `#api` `#docker`
