---
title: Portfolio BTS SIO
---

# Portfolio — BTS SIO

Bienvenue 👋 Ce site regroupe **mes réalisations** et **ma veille technologique** au format court et lisible.

## 🔗 Accès direct
- 👉 [Fiches projets](./projets/)
- 👉 [Veille technologique](./veille/)

## ℹ️ À propos
- Option : SLAM / SISR
- Période : 20XX–20XX
- Contact : email_pro@exemple.com
