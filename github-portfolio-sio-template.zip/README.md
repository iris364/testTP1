# Portfolio BTS SIO — {NOM Prénom}

> Dépôt “drive” : code source + documentation (projets, veille, rapports).

## 🎯 Objectif
Présenter clairement mes réalisations (SLAM/SISR) et ma veille technologique, de façon professionnelle et lisible par un examinateur.

## 🔧 Périmètre du dépôt
- `src/` : code source principal (projets, TP significatifs)
- `docs/` : documentation présentée au jury
  - `docs/projets/` : fiches-projet prêtes à lire
  - `docs/veille/` : fiches de veille (format court)
- `assets/` : captures d’écran, schémas, logos
- `tests/` : scripts de tests (si applicables)

## 🗂 Sommaire rapide
- [Fiches projets](docs/projets/)
- [Veille technologique](docs/veille/)
- [Guide d’installation](#-installation)
- [Roadmap / To‑do](#-roadmap)

---

## 🧱 Stack principale (exemple SLAM)
- PHP 8.x, Composer
- MySQL/MariaDB
- Laravel / Symfony
- Front : HTML/CSS/JS (+ framework si utilisé)

_(Adapter selon votre option / vos projets : SISR → Docker, Ansible, VMware, etc.)_

## 📸 Captures d’écran (exemples)
Images dans `assets/`. Insérer ici 1–2 images clés pour chaque projet.

---

## ⚙️ Installation
```bash
# Exemple SLAM Laravel
git clone https://github.com/<votre-compte>/<ce-repo>.git
cd <ce-repo>
cp .env.example .env
composer install
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

## 🧪 Tests
```bash
php artisan test
```

## 📄 Licences & droits
- Code : licence MIT (voir `LICENSE`)
- Documents (rapports, fiches) : © {NOM Prénom}, usage éducatif

## 🗺 Roadmap
- [ ] Finaliser doc utilisateur projet A
- [ ] Ajouter tests unitaires sur module X
- [ ] Préparer démonstration pour l’oral E4/E5

---

## 🧭 Navigation “jury friendly”
- Pages web statiques via GitHub Pages : `docs/` sert de site (voir `docs/index.md`).
- Veille concise (3–5 lignes) + impact métier (2–3 phrases) par fiche.
- Fiches projets = **1 page par projet** (contexte → livrables → résultats).

**Contact** : <email_pro@exemple.com>
